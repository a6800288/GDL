<?php

#取值 none | codepay | trimepay | f2fpay | chenAlipay | paymentwall | spay |tomatopay | payjs
$System_Config['payment_system']='gdl';
#GDL
$System_Config['gdl']=['config'=>['hid'=>'1000','key'=>'xxxxxxxxxxxx','url'=>'https://xxxx.xxx/']];	
