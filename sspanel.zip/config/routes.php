<?php
$app->post('/gdl_back/{type}', 'App\Services\Payment:notify');
$app->get('/gdl_back/{type}', 'App\Services\Payment:notify');
